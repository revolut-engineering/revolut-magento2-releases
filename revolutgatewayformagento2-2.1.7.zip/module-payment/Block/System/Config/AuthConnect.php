<?php

namespace Revolut\Payment\Block\System\Config;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\Exception\LocalizedException;
use Revolut\Payment\Model\Helper\Logger;
use Revolut\Payment\Gateway\Config\Config;
use Revolut\Payment\Model\RevolutOrder;
use Magento\Framework\UrlInterface;
use Revolut\Payment\Model\Helper\ConstantValue;
use Revolut\Payment\Model\Helper\Api\RevolutWebhookApi;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Revolut\Payment\Infrastructure\ServiceProvider;
use Revolut\Payment\Infrastructure\Config\Environment;

class AuthConnect extends Field
{
    /**
     * @var string
     */
    protected $_template = 'Revolut_Payment::system/config/auth_connect.phtml';

    /**
     * @var ModuleListInterface
     */
    protected $moduleList;

    /**
     * @var Logger
     */
    protected $logger;
    
    /**
     * @var RevolutWebhookApi
     */
    protected $webhookApi;
    
    /**
     * @var Config
     */
    protected $config;
    
    /**
     * @var RevolutOrder
     */
    protected $revolutOrder;
    
    /**
     * @var UrlInterface
     */
    protected $urlHelper;
    
    /**
     * @var SessionManagerInterface
     */
    protected $session;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * Webhook constructor.
     *
     * @param Context $context
     * @param Config $config
     * @param UrlInterface $urlHelper
     * @param SessionManagerInterface $session
     * @param Logger $logger
     * @param RevolutWebhookApi $webhookApi
     * @param RevolutOrder $revolutOrder
     * @param ModuleListInterface $moduleList
     * @param StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        Context $context,
        Config $config,
        UrlInterface $urlHelper,
        SessionManagerInterface $session,
        Logger $logger,
        RevolutWebhookApi $webhookApi,
        RevolutOrder $revolutOrder,
        ModuleListInterface $moduleList,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->logger = $logger;
        $this->config = $config;
        $this->urlHelper = $urlHelper;
        $this->session = $session;
        $this->webhookApi = $webhookApi;
        $this->revolutOrder = $revolutOrder;
        $this->storeManager = $storeManager;
        $this->moduleList = $moduleList;
        parent::__construct($context, $data);
    }

    public function getCacheLifetime()
    {
        return 0;
    }

    /**
     * @return string
     */
    public function getConnectServerUrlDev()
    {
        $storeId = $this->storeManager->getStore()->getId();
        return ServiceProvider::apiConfigProvider($storeId)->getConfig((string) Environment::DEV)->getConnectServerUrl();
    }

    /**
     * @return string
     */
    public function getConnectServerUrlProd()
    {
        $storeId = $this->storeManager->getStore()->getId();
        return ServiceProvider::apiConfigProvider($storeId)->getConfig((string) Environment::PROD)->getConnectServerUrl();
    }
    
    /**
     * @return string
     */
    public function getAuthConnectAjaxUrl()
    {
        return $this->getUrl('revolut/authconnect/setup', ['store' => $this->getRequest()->getParam('store', 0)]);
    }

    /**
     * @return bool
     */
    public function storeHasValidTokens()
    {
        $storeId = $this->storeManager->getStore()->getId();
        $tokenRepo = ServiceProvider::optionTokenRepository($storeId);

        $tokens = $tokenRepo->getTokens();

        if (empty($tokens)) {
            return false;
        }

        try {
            $result = ServiceProvider::legacyMerchantApi($storeId)->get('/webhooks');
            if (is_array($result) && isset($result['code'])) {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * @param  AbstractElement $element
     * @return string
     */
    public function render(AbstractElement $element)
    {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
        return parent::render($element);
    }

    /**
     * @param  AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element)
    {
        return $this->_toHtml();
    }
}
