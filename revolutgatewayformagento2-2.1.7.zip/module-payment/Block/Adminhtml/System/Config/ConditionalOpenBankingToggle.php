<?php
namespace Revolut\Payment\Block\Adminhtml\System\Config;

use Magento\Config\Block\System\Config\Form\Fieldset;

use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Store\Model\StoreManagerInterface;
use Revolut\Payment\Gateway\Config\PayByBank\Config as OpenBankingConfig;
use Magento\Backend\Block\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Framework\View\Helper\Js;

class ConditionalOpenBankingToggle extends Fieldset
{

    /**
     * @var OpenBankingConfig
     */
    private $openBankingConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    public function __construct(
        Context $context,
        Session $authSession,
        Js $jsHelper,
        OpenBankingConfig $openBankingConfig,
        StoreManagerInterface $storeManager,
        array $data = []
    ) {
        parent::__construct($context, $authSession, $jsHelper, $data);
        $this->openBankingConfig = $openBankingConfig;
        $this->storeManager = $storeManager;
    }

    public function render(AbstractElement $element)
    {

        $store = $this->storeManager->getStore();

        if (! $this->openBankingConfig->isAllowed($store->getId(), $store->getCurrentCurrencyCode())) {
            return '';
        }
        
        return parent::render($element);
    }
}
