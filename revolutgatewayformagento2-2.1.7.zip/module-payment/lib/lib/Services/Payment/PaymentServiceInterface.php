<?php

namespace Revolut\Plugin\Services\Payment;

use Revolut\Plugin\Types\PaymentAmount;

interface PaymentServiceInterface
{
    public function refund(string $orderId, PaymentAmount $amount);
    public function cancel(string $orderId);
    public function capture(string $orderId);
}
