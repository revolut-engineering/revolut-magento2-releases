<?php

namespace Revolut\Plugin\Services\Payment;

use Revolut\Plugin\Services\Payment\PaymentModel;

interface PaymentRepositoryInterface
{
    public function findByPlatformCartId(string $cartId): ?PaymentModel;
    public function findByPlatformOrderId(string $orderId): PaymentModel;
    public function findByRevolutOrderId(string $revolutOrderId): PaymentModel;
    public function add(PaymentModel $payment): void;
    public function save(PaymentModel $payment): void;
}
