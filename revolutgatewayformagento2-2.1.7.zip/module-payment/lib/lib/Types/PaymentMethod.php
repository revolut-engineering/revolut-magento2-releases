<?php

namespace Revolut\Plugin\Types;

use Exception;
use Revolut\Plugin\Types\ValueObject;

class PaymentMethod extends ValueObject
{
      /** @var string */
    private $method;

    /** @var string  */
    public const CARD = "card";

    /** @var string  */
    public const CARD_SUBSCRIPTION = "card_subscription";

    /** @var string  */
    public const REVOLUT_PAY = "revolut_pay";

    /** @var string  */
    public const RPAY_FAST_CHECKOUT = "rpay_fast_checkout";

    /** @var string  */
    public const PAYMENT_REQUEST = "payment_request";

    /** @var string  */
    public const PAYMENT_REQUEST_FAST_CHECKOUT = "payment_request_fast_checkout";

    /** @var string  */
    public const PAY_BY_BANK = "pay_by_bank";

    /** @var string  */
    public const FAST_CHECKOUT = "fast_checkout";

    /** @var array  */
    public const PAYMENT_METHODS = [
        self::CARD,
        self::CARD_SUBSCRIPTION,
        self::REVOLUT_PAY,
        self::PAYMENT_REQUEST,
        self::PAY_BY_BANK,
        self::RPAY_FAST_CHECKOUT,
        self::PAYMENT_REQUEST_FAST_CHECKOUT,
    ];

    private function __construct(string $method)
    {
        if (!in_array($method, self::PAYMENT_METHODS)) {
            throw new Exception("Invalid payment method value: $method");
        }

        $this->method = $method;
    }

    public function getValue(): string
    {
        return $this->method;
    }

    public function isPayByBank(): bool
    {
        return $this->method == self::PAY_BY_BANK;
    }

    public function isFastCheckout(): bool
    {
        return $this->method == self::FAST_CHECKOUT;
    }

    public static function of(string $method): PaymentMethod
    {
        return new PaymentMethod($method);
    }
}
