<?php

namespace Revolut\Payment\Gateway\Config\PayByBank;

use Revolut\Payment\Gateway\Config\PayByBank\Config as OpenBankingConfig;
use Revolut\Payment\Gateway\Config\Config as GlobalConfig;
use Magento\Payment\Gateway\Config\ValueHandlerInterface;
use Magento\Store\Model\StoreManagerInterface;

class IsActiveHandler implements ValueHandlerInterface
{
    /**
     * @var OpenBankingConfig
     */
    protected $config;

    /**
     *
     * @var GlobalConfig
     */
    protected $globalConfig;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    public function __construct(OpenBankingConfig $config, GlobalConfig $globalConfig, StoreManagerInterface $storeManager)
    {
        $this->config = $config;
        $this->globalConfig= $globalConfig;
        $this->storeManager = $storeManager;
    }

    /**
     * Retrieve method configured value
     *
     * @param array $subject
     * @param int $storeId
     *
     * @return mixed
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function handle(array $subject, $storeId = 0)
    {
        if (in_array('payment', array_keys($subject))) {
            return true;
        }

        $mode = $this->globalConfig->getModeName($storeId);

        if($mode === "sandbox" ) {
            return false;
        }

        return $this->config->isActive($storeId) && (bool) $this->globalConfig->getWebhookSetupResult($storeId);
    }
}
