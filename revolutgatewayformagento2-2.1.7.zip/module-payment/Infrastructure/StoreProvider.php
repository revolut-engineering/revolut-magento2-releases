<?php

namespace Revolut\Payment\Infrastructure;

use Magento\Framework\App\ObjectManager;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Framework\App\ScopeInterface;

class StoreProvider
{
    /**
     * @var  StoreManagerInterface|mixed
     */
    protected $storeManager;

    /**
     * @var RequestInterface|mixed
     */
    protected $request;

    public function __construct()
    {
        $this->storeManager = ObjectManager::getInstance()->get('Magento\Store\Model\StoreManagerInterface');
        $this->request = ObjectManager::getInstance()->get('Magento\Framework\App\RequestInterface');
    }

    /**
     * @return StoreInterface|null
     */
    public function getCurrentStore()
    {
        if (!$this->storeManager || !$this->request) {
            return null;
        }

        // Admin context — check for store param
        $storeId = (int) $this->request->getParam('store');

        if ($storeId) {
            return $this->storeManager->getStore($storeId);
        }

        $websiteCode = $this->request->getParam('website');
        if ($websiteCode) {
            $website = $this->storeManager->getWebsite($websiteCode);
            return $website->getDefaultStore();
        }

        $scope = $this->request->getParam('scope');
        if ($scope && $scope !== ScopeInterface::SCOPE_DEFAULT) {
            return $this->storeManager->getStore($scope);
        }

        return $this->storeManager->getStore();
    }
}
