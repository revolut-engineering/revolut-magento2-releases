<?php

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Services\AuthConnect\Exceptions\TokenRefreshInProgressException;
use Revolut\Plugin\Services\AuthConnect\TokenRefreshServiceInterface;
use Revolut\Plugin\Services\Lock\LockInterface;
use Revolut\Plugin\Services\Log\RLog;

class AuthConnectJob
{
    /**
     * @var LockInterface
     */
    private $tokenRefreshJobLock;

    /**
     * @var TokenRefreshServiceInterface
     */
    private $tokenRefreshService;

    public function __construct(
        LockInterface $tokenRefreshJobLock,
        TokenRefreshServiceInterface $tokenRefreshService
    ) {
        $this->tokenRefreshJobLock = $tokenRefreshJobLock;
        $this->tokenRefreshService = $tokenRefreshService;
    }

    public function run(): void
    {
        try {
            $this->refreshTokenJob();
        } catch (\Exception $e) {
            if ($e instanceof TokenRefreshInProgressException) {
                return;
            }

            RLog::error('refresh_token job error. ' . $e->getMessage());
        }
    }
    /**
     * @return void
     * @throws TokenRefreshInProgressException
     */
    public function refreshTokenJob(): void
    {
        if (!$this->tokenRefreshJobLock->acquire()) {
            throw new TokenRefreshInProgressException('token refresh in progress...');
        }

        try {
            RLog::info('refresh_token job start.');
            // On Multi store supported platforms as Magento
            // Refresh job and on demand refresh process should run **Synonymously**
            // Due to the fact that only 2 refresh process could run asynchronously
            $this->tokenRefreshService->tryRefreshTokenWithLock();
            RLog::info('refresh_token job completed.');
        } catch (\Exception $e) {
            $dt = \DateTime::createFromFormat('U.u', (string) microtime(true));
            $formattedDt = $dt ? $dt->format('H:i:s.u') : 'unknown time';
            RLog::error('refreshToken error - ' . $e->getMessage() . ' - ' . $formattedDt);
        }
    }
}
