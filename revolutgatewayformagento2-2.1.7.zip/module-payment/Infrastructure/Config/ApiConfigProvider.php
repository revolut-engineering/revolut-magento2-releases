<?php

namespace Revolut\Payment\Infrastructure\Config;

use Magento\Framework\App\ObjectManager;
use Revolut\Plugin\Infrastructure\Config\Api\DevConfig;
use Revolut\Payment\Infrastructure\Config\Environment;
use Revolut\Plugin\Infrastructure\Config\Api\ProdConfig;
use Revolut\Plugin\Infrastructure\Config\Api\SandboxConfig;
use Revolut\Plugin\Services\Config\Api\ConfigInterface;
use Revolut\Plugin\Services\Config\Api\ConfigProviderInterface;
use Revolut\Payment\Gateway\Config\Config;
use Revolut\Plugin\Services\Log\RLog;
use Revolut\Plugin\Services\Repositories\TokenRepositoryInterface;

class ApiConfigProvider implements ConfigProviderInterface
{
    /**
     * @var Config|mixed
     */
    protected $configRepository;

    /**
     * @var TokenRepositoryInterface
     */
    protected $tokenRepo;

    /**
     *
     * @var int
     */
    protected $storeId;

    public function __construct(
        int $storeId,
        TokenRepositoryInterface $tokenRepo
    ) {
        $this->configRepository = ObjectManager::getInstance()->get('Revolut\Payment\Gateway\Config\Config');
        $this->storeId = $storeId;
        $this->tokenRepo = $tokenRepo;
    }

    public function getConfig(?string $mode = null): ConfigInterface
    {
        if ($mode === null) {
            $mode = $this->configRepository->getApiMode($this->storeId);
        }
        
        switch ($mode) {
            case Environment::PROD:
                $config = new ProdConfig();
                break;
            case Environment::DEV:
                $config = new DevConfig();
                break;
            case Environment::SANDBOX:
                $config = new SandboxConfig();
                break;
            default:
                $config = new ProdConfig();
                break;
        }

        $config->setSecretKey($this->getSecretKey($mode));
        $config->setPublicKey($this->getPublicKey($mode));

        return $config;
    }

    public function getSecretKey(string $mode): string
    {
        $storeId = $this->storeId;

        switch ($mode) {
            case Environment::PROD:
                return $this->configRepository->getLiveApiKey($storeId);
            case Environment::DEV:
                return $this->configRepository->getDevApiKey($storeId);
            case Environment::SANDBOX:
                return $this->configRepository->getSandboxApiKey($storeId);
            default:
                return $this->configRepository->getLiveApiKey($storeId);
        }
    }

    public function getPublicKey(string $mode): string
    {
        switch ($mode) {
            case Environment::PROD:
                return $this->configRepository->getLivePublicApiKey($this->storeId);
            case Environment::DEV:
                return $this->configRepository->getDevPublicApiKey($this->storeId);
            case Environment::SANDBOX:
                return $this->configRepository->getSandboxPublicApiKey($this->storeId);
            default:
                return $this->configRepository->getLivePublicApiKey($this->storeId);
        }
    }

    public function isAccessTokenConfigured(): bool
    {
        $token = $this->tokenRepo->getTokens();
        return !empty($token->accessToken) && !empty($token->accessToken);
    }
}
