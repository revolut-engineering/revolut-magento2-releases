<?php

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Services\Log\LoggerInterface;
use Revolut\Payment\Model\Helper\Logger as MagentoLogger;

class Logger implements LoggerInterface
{
    private const LOG_CONTEXT = ['source' => 'revolut-gateway-for-magento'];

    /**
     * @var MagentoLogger
     */
    private static $logger;

    /**
     * @param MagentoLogger $logger
     * @return void
     */
    public static function setLogger($logger)
    {
        self::$logger = $logger;
    }
    
    /**
     * @param string $message
     * @param array $context
     * @return void
     */
    public function info(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->info(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }

    /**
     * @param string $message
     * @param array $context
     * @return void
     */
    public function error(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->error(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }

    /**
     * @param string $message
     * @param array $context
     * @return void
     */
    public function debug(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->debug(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }
}
