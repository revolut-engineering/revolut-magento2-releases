<?php

namespace Revolut\Payment\Infrastructure;

use Magento\Framework\Exception\LocalizedException;
use Revolut\Plugin\Services\Repositories\OptionRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\CacheInterface;

class OptionRepository implements OptionRepositoryInterface
{
    /**
     * @var ResourceConnection|mixed
     */
    protected $connection;
    /**
     * @var string|mixed
     */
    protected $tableName;

    /**
     * @var int
     */
    protected $storeId;

    /**
     * @var CacheInterface
     */
    protected $cache;
    
    /**
     *
     * @param int $storeId
     * @param ResourceConnection $resource
     * @param CacheInterface $cache
     */
    public function __construct($storeId, ResourceConnection $resource, CacheInterface $cache)
    {
        $this->cache = $cache;
        $this->connection = $resource->getConnection();
        $this->tableName = $resource->getTableName('revolut_options');
        $this->storeId = $storeId;
    }
    
    /**
     * @param mixed $value
     * @return mixed
     */
    private function maybeEncode($value)
    {
        if (is_array($value)) {
            return json_encode($value);
        }

        return $value;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private function maybeDecode($value)
    {
        if (!is_string($value)) {
            return $value;
        }

        $data = json_decode($value, true);

        if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
            return $data;
        }

        return $value;
    }

    /**
     *
     * @param string $name
     * @param mixed $value
     * @return bool
     */
    public function add($name, $value)
    {
        try {
            $this->connection->insert($this->tableName, [
                'store_id' => $this->storeId,
                'option_name' => $name,
                'option_value' => $this->maybeEncode($value)
            ]);
            return true;
        } catch (\Zend_Db_Statement_Exception $e) {
            // Duplicate entry due to UNIQUE constraint
            return false;
        } catch (\Exception $e) {
            if (strpos($e->getMessage(), 'SQLSTATE[23000]') !== false) {
                // Duplicate entry due to UNIQUE constraint
                return false;
            }
            throw new LocalizedException(__('Add failed: %1', $e->getMessage()));
        }
    }

    /**
     * @param string $name
     * @return bool
     */
    public function delete($name)
    {
        return (bool) $this->connection->delete($this->tableName, ['option_name = ?' => $name, 'store_id = ?' => $this->storeId]);
    }

    /**
     * @param string $name
     * @param array|mixed $value
     * @return bool
     */
    public function update($name, $value)
    {
        return (bool) $this->connection->update(
            $this->tableName,
            ['option_value' => $this->maybeEncode($value)],
            ['option_name = ?' => $name, 'store_id = ?' => $this->storeId]
        );
    }

    /**
     * @param string $name
     * @param array|mixed $value
     * @return bool
     * @throws LocalizedException
     */
    public function addOrUpdate($name, $value)
    {
        try {
            $this->connection->insertOnDuplicate(
                $this->tableName,
                ['store_id' => $this->storeId, 'option_name' =>  $name, 'option_value' => $this->maybeEncode($value)],
                ['option_value']
            );
            return true;
        } catch (\Exception $e) {
            throw new LocalizedException(__('addOrUpdate failed: %1', $e->getMessage()));
        }
    }

    /**
     * @param string $name
     * @return mixed
     */
    public function get($name)
    {
        $select = $this->connection->select()
            ->from($this->tableName, ['option_value'])
            ->where('option_name = :name')
            ->where('store_id = ?', $this->storeId);

        /**
         * @var mixed
         */
        $result = $this->connection->fetchOne($select, ['name' => $name]);
        return $result !== false ?  $this->maybeDecode($result) : null;
    }
    
    /**
     * @param string $key
     * @param mixed $value
     * @param int $ttlSeconds
     * @return bool
     */
    public function addCached($key, $value, $ttlSeconds): bool
    {
        return $this->cache->save($this->maybeEncode($value), $key, [], $ttlSeconds);
    }

    /**
     * @param string $key
     * @return mixed
     */
    public function getCached($key)
    {
        return $this->maybeDecode($this->cache->load($key));
    }
}
