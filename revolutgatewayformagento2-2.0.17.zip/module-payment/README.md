## Revolut Payment plugin for Adobe Commerce (Magento 2)

### Documentation

 - [Installation](https://developer.revolut.com/docs/guides/accept-payments/plugins/magento/installation)
 - [Configuration](https://developer.revolut.com/docs/guides/accept-payments/plugins/magento/configuration)