<?php

namespace Revolut\Payment\Observer;

use Exception;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Message\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Revolut\Plugin\Infrastructure\Api\MerchantApi;
use Revolut\Plugin\Services\Log\RLog;
use Revolut\Payment\Model\Helper\Api\RevolutApi;
use Revolut\Payment\Gateway\Config\Config as GlobalConfig;
use Throwable;

class AdminSystemConfigChangedObserver implements ObserverInterface
{
    /**
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     *
     * @var RevolutApi
     */
    protected $revolutApi;

    /**
     * @var GlobalConfig
     */
    protected $config;

    /**
     * @param ManagerInterface $messageManager
     * @param StoreManagerInterface $storeManager
     * @param RevolutApi $revolutApi
     * @param GlobalConfig $config
     */
    public function __construct(
        ManagerInterface $messageManager,
        StoreManagerInterface $storeManager,
        RevolutApi $revolutApi,
        GlobalConfig $config
    ) {
        $this->messageManager = $messageManager;
        $this->storeManager = $storeManager;
        $this->revolutApi = $revolutApi;
        $this->config = $config;
    }
    /**
     * @param ObserverInterface $observer
     * @return ObserverInterface
     */
    public function execute($observer)
    {

        try {
            $storeId = $this->storeManager->getStore()->getId();
            $storeCurrency = $this->storeManager->getStore()->getCurrentCurrencyCode();
            
            $this->savePublicKey($storeId);
            $this->saveAvailablePaymentMethods($storeId, $storeCurrency);

        } catch (Throwable $e) {
            RLog::error("AdminSystemConfigChangedObserver Error  - " . $e->getMessage());
            $this->messageManager->addErrorMessage(__('Something went wrong while fetching available payment methods'));
        }

        return $this;
    }

    /**
     * @param int $storeId
     * @throws Exception
     * @return void
     */
    public function savePublicKey($storeId)
    {
        $publicKey = $this->revolutApi->getMerchantPublicKey($storeId);
            
        if (empty($publicKey)) {
            throw new Exception("Failed to fetch public key");
        }

        $this->config->savePublicApiKey($publicKey, $storeId);
    }

    /**
     * @param int $storeId
     * @param string $storeCurrency
     * @throws Exception
     * @return void
     */
    public function saveAvailablePaymentMethods($storeId, $storeCurrency)
    {
        $availablePaymentMethods = MerchantApi::merchantDetails()->availablePaymentMethods(0, $storeCurrency);
        if (empty($availablePaymentMethods)) {
            throw new Exception("Failed to fetch available payment methods");
        }

        $this->config->saveAvailablePaymentMethods($availablePaymentMethods, $storeCurrency, $storeId);
    }
}
