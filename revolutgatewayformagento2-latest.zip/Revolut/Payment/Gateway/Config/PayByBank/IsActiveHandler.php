<?php

namespace Revolut\Payment\Gateway\Config\PayByBank;

use Magento\Payment\Gateway\Config\ValueHandlerInterface;
use Revolut\Payment\Model\Helper\Api\RevolutApi;
use Revolut\Payment\Model\Helper\ConstantValue;

class IsActiveHandler implements ValueHandlerInterface
{
    /**
     * Revolut Api instance
     *
     * @var RevolutApi
     */
    protected $revolutApi;

    public function __construct(RevolutApi $revolutApi)
    {
        $this->revolutApi = $revolutApi;
    }

    /**
     * Retrieve method configured value
     *
     * @param array $subject
     * @param int $storeId
     *
     * @return mixed
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function handle(array $subject, $storeId = 0)
    {
        if (in_array('payment', array_keys($subject))) {
            return true;
        }
        return $this->isAllowed($storeId);
    }

    /**
     * Pay by bank is supported on merchant level
     *
     * @param int $storeId
     * @return boolean
     */
    public function isAllowed($storeId)
    {
        $features = $this->revolutApi->getMerchantFeatures($storeId);
        return in_array(ConstantValue::OPENBANKING_EUROPE_ENABLE_FLAG, $features, true);
    }
}
