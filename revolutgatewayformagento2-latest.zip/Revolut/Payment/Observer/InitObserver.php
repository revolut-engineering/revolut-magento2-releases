<?php

namespace Revolut\Payment\Observer;

use Magento\Framework\App\RequestInterface;
use Revolut\Payment\Infrastructure\ServiceProvider;
use Magento\Store\Model\StoreManagerInterface;

class InitObserver
{
     /**
      * @var StoreManagerInterface
      */
    protected $storeManager;

    /**
     * Constructor
     *
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        StoreManagerInterface $storeManager
    ) {
        $this->storeManager = $storeManager;
    }

    public function beforeDispatch(
        \Magento\Framework\App\FrontControllerInterface $subject,
        RequestInterface $request
    ) {
        try {
            ServiceProvider::logger();

            $stores = $this->storeManager->getStores();

            foreach ($stores as $store) {
                if (empty($store->getId())) {
                    continue;
                }
              
                ServiceProvider::authConnectJob($store->getId())->run();
            }
        } catch (\Exception $e) {
            ServiceProvider::logger()->debug("authConnectJob error - " . $e->getMessage());
        }

        return [$request];
    }
}
