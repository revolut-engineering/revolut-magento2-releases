<?php

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Services\Log\LoggerInterface;
use Magento\Framework\App\ObjectManager;

class Logger implements LoggerInterface
{
    private const LOG_CONTEXT = ['source' => 'revolut-gateway-for-magento'];
    private static $logger;

    public static function setLogger($logger)
    {
        self::$logger = $logger;
    }

    public function info(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->info(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }

    public function error(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->error(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }

    public function debug(string $message, array $context = self::LOG_CONTEXT)
    {
        self::$logger->debug(self::LOG_CONTEXT['source'] . ' - ' . $message);
    }
}
