<?php

namespace Revolut\Payment\Infrastructure\Config;

use Magento\Framework\App\ObjectManager;
use Revolut\Plugin\Infrastructure\Config\Api\DevConfig;
use Revolut\Payment\Infrastructure\Config\Environment;
use Revolut\Plugin\Infrastructure\Config\Api\ProdConfig;
use Revolut\Plugin\Infrastructure\Config\Api\SandboxConfig;
use Revolut\Payment\Infrastructure\ServiceProvider;
use Revolut\Plugin\Services\Config\Api\ConfigInterface;
use Revolut\Plugin\Services\Config\Api\ConfigProviderInterface;
use Magento\Store\Model\ScopeInterface;
use Revolut\Plugin\Services\Repositories\TokenRepositoryInterface;

class ApiConfigProvider implements ConfigProviderInterface
{
    protected $configRespository;
    protected $tokenRepo;
    protected $storeId;

    public function __construct(
        $storeId,
        $tokenRepo
    ) {
        $this->configRespository = ObjectManager::getInstance()->get('Revolut\Payment\Gateway\Config\Config');
        $this->storeId = $storeId;
        $this->tokenRepo = $tokenRepo;
    }

    public function getConfig(?string $mode = null): ConfigInterface
    {
        if ($mode === null) {
            $mode = $this->configRespository->getApiMode($this->storeId);
        }
        
        switch ($mode) {
            case Environment::PROD:
                $config = new ProdConfig();
                break;
            case Environment::DEV:
                $config = new DevConfig();
                break;
            case Environment::SANDBOX:
                $config = new SandboxConfig();
                break;
            default:
                $config = new ProdConfig();
                break;
        }

        $config->setSecretKey($this->getSecretKey($mode));
        $config->setPublicKey($this->getPublicKey($mode));

        return $config;
    }

    public function getSecretKey($mode)
    {
        $storeId = $this->storeId;

        switch ($mode) {
            case Environment::PROD:
                return $this->configRespository->getLiveApiKey($storeId);
            case Environment::DEV:
                return $this->configRespository->getDevApiKey($storeId);
            case Environment::SANDBOX:
                return $this->configRespository->getSandboxApiKey($storeId);
            default:
                return $this->configRespository->getLiveApiKey($storeId);
        }

        return $this->getSecretKey($this->configRespository->getApiKey($this->storeId));
    }

    public function getPublicKey($mode)
    {
        switch ($mode) {
            case Environment::PROD:
                return $this->configRespository->getLivePublicApiKey($this->storeId);
            case Environment::DEV:
                return $this->configRespository->getDevPublicApiKey($this->storeId);
            case Environment::SANDBOX:
                return $this->configRespository->getSandboxPublicApiKey($this->storeId);
            default:
                return $this->configRespository->getLivePublicApiKey($this->storeId);
        }
    }

    public function isAccessTokenConfigured()
    {
        $token = $this->tokenRepo->getTokens();
        return !empty($token->accessToken) && !empty($token->accessToken);
    }
}
