<?php

namespace Revolut\Payment\Model\Helper;

class Logger extends \Monolog\Logger
{

}
