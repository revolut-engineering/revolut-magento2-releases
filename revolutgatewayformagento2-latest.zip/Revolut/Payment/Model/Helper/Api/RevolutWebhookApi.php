<?php

namespace Revolut\Payment\Model\Helper\Api;

use Revolut\Payment\Infrastructure\ServiceProvider;
use Revolut\Payment\Model\Helper\ConstantValue;

/**
 * Class RevolutOrderApi
 */
class RevolutWebhookApi extends RevolutApi
{
    /**
     * Set via API
     *
     * @param string $webhookUrl
     * @param int $storeId
     * @return array result
     */
    public function set($webhookUrl, $storeId)
    {
        $payload = [
            "url" => $webhookUrl,
            "events" => ["ORDER_COMPLETED", "ORDER_AUTHORISED"]
        ];
        
        return ServiceProvider::legacyMerchantApi($storeId)->post('/webhooks', $payload);
    }
    
    /**
     * Update via API
     *
     * @param string $webhookUrl
     * @param string $webhookId
     * @param int $storeId
     * @return array result
     */
    public function update($webhookUrl, $webhookId, $storeId)
    {
        $payload = [
            "url" => $webhookUrl,
            "events" => ["ORDER_COMPLETED", "ORDER_AUTHORISED"]
        ];

        return ServiceProvider::legacyMerchantApi($storeId)->put('/webhooks/'.$webhookId, $payload);
    }

    /**
     * Clears Webhook list on API
     *
     * @param  int $storeId
     * @return void.
     */
    public function clear($storeId)
    {
        foreach ($this->list($storeId) as $webhook) {
            if (!isset($webhook['id'])) {
                continue;
            }
            ServiceProvider::legacyMerchantApi($storeId)->delete('/webhooks/'.$webhook['id']);
        }
    }

    /**
     * Retrieves Webhook list on API
     *
     * @param  int $storeId
     * @return array
     */
    public function list($storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->get('/webhooks');
    }

    /**
     * Get Webhooks API URL
     *
     * @param  int $storeId
     * @param  string $webhookId
     * @return string
     */
    public function getApiUrl($storeId, $webhookId = '')
    {
        $apiUrl = $this->config->getApiUrl($storeId) . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_WEBHOOK;

        if ($webhookId) {
            $apiUrl .= '/' . $webhookId;
        }

        return $apiUrl;
    }
}
