# Changelog

## 2.0.16

- Fixed virtual product order processing error

## 2.0.15

- Added Revolut promotional banners

## 2.0.14

- Fixed line item tax and discount amount format

## 2.0.13

- Added logic for collecting line items & proof of shipping

## 2.0.12

- Improved loading speed of payment options
- Fixed one page checkout payment total difference issue

## 2.0.11

- Fixed checkout page payment processing error

## 2.0.10

- Updated CSP rules

## 2.0.9

- Fixed an issue where in some cases total amount did not include shipping cost

## 2.0.8

- Fixed Payment Request Button duplicated webhook order processing issue

## 2.0.7

- Added Card holder name input configuration

## 2.0.6

- Fixed refund issue

## 2.0.5

- Improved fast checkout address validation
- Improved logging

## 2.0.4

- Fixed card gateway webhook order processing issue
- Fixed Laminas framework compatibility

## 2.0.3

- Improved Revolut Pay mobile order processing
- Added configuration for disabling Revolut Pay cashback message

## 2.0.2

- Fixed Revolut Pay fast checkout mobile redirection

## 2.0.1

- Fixed Revolut Pay fast checkout carrier issue

## 2.0.0

- Added Revolut Pay redirection URLs
- Added Apple Pay - Google Pay
- Added Revolut Pay Fast Checkout
- Added Reward Banner
- Fixed Orders processing with webhooks

## 1.0.0

- Initial version.
