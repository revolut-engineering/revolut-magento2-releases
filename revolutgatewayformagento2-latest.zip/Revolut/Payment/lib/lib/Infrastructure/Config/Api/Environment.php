<?php

namespace Revolut\Plugin\Infrastructure\Config\Api;

class Environment
{
    public const DEV = "dev";
    public const SANDBOX = "sandbox";
    public const PROD = "live";
}
