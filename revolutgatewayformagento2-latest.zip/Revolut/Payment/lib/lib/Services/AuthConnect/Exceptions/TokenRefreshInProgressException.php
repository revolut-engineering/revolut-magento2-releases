<?php

namespace Revolut\Plugin\Services\AuthConnect\Exceptions;

class TokenRefreshInProgressException extends \Exception
{
}
