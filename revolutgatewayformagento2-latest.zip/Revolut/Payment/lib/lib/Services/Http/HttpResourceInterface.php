<?php

namespace Revolut\Plugin\Services\Http;

interface HttpResourceInterface
{
    public function registerRoutes();
}
