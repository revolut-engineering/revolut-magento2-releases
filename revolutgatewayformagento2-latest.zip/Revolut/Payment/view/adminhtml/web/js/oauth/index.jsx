import React from 'react'
import { OAuthConnect } from './oauth/OAuthConnect'

import { createRoot } from 'react-dom/client'
import { RootProvider, ThemeProvider } from '@revolut/ui-kit'

const App = ({ mode }) => {
  return (
    <RootProvider>
      <ThemeProvider>
        <OAuthConnect mode={mode} />
      </ThemeProvider>
    </RootProvider>
  )
}

const init = () => {
  const devContainer = document.getElementById('REVOLUT_OAUTH_CONNECT_BUTTON_DEV')
  const prodContainer = document.getElementById('REVOLUT_OAUTH_CONNECT_BUTTON_LIVE')

  if (devContainer) {
    const root = createRoot(devContainer)
    root.render(<App mode="dev" />)
  }

  if (prodContainer) {
    const root = createRoot(prodContainer)
    root.render(<App mode="live" />)
  }
}
setTimeout(() => {
  init()
}, 500)
