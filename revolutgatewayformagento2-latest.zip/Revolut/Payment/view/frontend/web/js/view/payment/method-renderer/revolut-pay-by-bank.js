/*browser:true*/
/*global define*/

define([
  'jquery',
  'Revolut_Payment/js/view/payment/method-renderer/revolut-payment-component-core',
  'Magento_Checkout/js/model/full-screen-loader',
  'Magento_Checkout/js/action/set-payment-information',
  'ko',
  window.checkoutConfig.payment.revolut.revolutSdk,
], function ($, Component, fullScreenLoader, setPaymentInformation, ko, RevolutCheckout) {
  'use strict'
  return Component.extend({
    defaults: {
      template: 'Revolut_Payment/payment/revolut-pay-by-bank',
      revolutSdk: window.checkoutConfig.payment.revolut.revolutSdk,
      pbbInstance: ko.observable(null),
      publicId: ko.observable(null),
      payByBankMethodCode: 'revolut_pay_by_bank',
      errorWidgetTarget: '#show-pay-by-bank-error',
    },

    createRevolutWidgetInstance: function () {
      let pbbInstance = this.pbbInstance()
      let self = this

      if (pbbInstance !== null) {
        pbbInstance.destroy()
      }

      const publicToken = this.getPaymentConfig('publicKey')
      const locale = this.getPaymentConfig('locale')
      if (!publicToken) {
        return self.handleError({
          message:
            'Something went wrong. Required parameters to initiate the payment were missing',
        })
      }

      const checkoutInstance = RevolutCheckout.payments({
        locale: locale,
        publicToken: publicToken,
      })

      const paymentOptions = {
        instantOnly: true,
        createOrder: () => {
          return self
            .createOrUpdateRevolutOrder(self.payByBankMethodCode)
            .then(() => {
              return $.when(setPaymentInformation(self.messageContainer, self.getData()))
                .then(() => self.updateOrderTotals())
                .then(() => ({ publicId: self.publicId() }))
            })
        },
        onError: errorMsg => {
          if (errorMsg.error) {
            self.handleError(errorMsg.error)
          } else {
            self.handleError(errorMsg)
          }
          fullScreenLoader.stopLoader()
        },
        onCancel: () => {
          self.handleCancel()
          fullScreenLoader.stopLoader()
        },
        onSuccess: () => {
          self.handleSuccess()
        },
      }

      this.pbbInstance(checkoutInstance.payByBank(paymentOptions))
      fullScreenLoader.stopLoader()
    },
    triggerPayByBank: function () {
      if (this.pbbInstance() !== null) {
        fullScreenLoader.startLoader()
        this.pbbInstance().show()
      }
    },
    showPayByBankLogos: function () {
      const bankBrands = JSON.parse(this.getPaymentConfig('bankBrands', []))
      if (!bankBrands) return []

      const { institutions, popular_institution_ids } = bankBrands
      if (!institutions || !popular_institution_ids) {
        return []
      }
      const popular = popular_institution_ids
        .map(id =>
          institutions.find(bank => Object.values(bank.details)[0].institution_id === id),
        )
        .filter(Boolean)
      const nonPopular = institutions.filter(
        bank =>
          !popular_institution_ids.includes(
            Object.values(bank.details)[0].institution_id,
          ),
      )

      const bankList = [...popular, ...nonPopular]

      return bankList.slice(0, 5).map(bank => bank.logo.value)
    },
    getCode: function () {
      return 'revolut_pay_by_bank'
    }
  })
})
