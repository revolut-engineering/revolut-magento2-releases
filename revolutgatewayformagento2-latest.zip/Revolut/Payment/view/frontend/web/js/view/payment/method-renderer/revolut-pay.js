/*browser:true*/
/*global define*/

define([
  'jquery',
  'Revolut_Payment/js/view/payment/method-renderer/revolut-payment-component-core',
  'Magento_Checkout/js/model/full-screen-loader',
  'ko',
  'Magento_Checkout/js/model/quote',
  'mage/storage',
  'Magento_Checkout/js/model/url-builder',
  window.checkoutConfig.payment.revolut.revolutSdk,
], function (
  $,
  Component,
  fullScreenLoader,
  ko,
  quote,
  storage,
  urlBuilder,
  RevolutCheckout,
) {
  'use strict'
  return Component.extend({
    defaults: {
      template: 'Revolut_Payment/payment/revolut-pay',
      revolutSdk: window.checkoutConfig.payment.revolut.revolutSdk,
      revolutPay: ko.observable(null),
      errorWidgetTarget: '#show-error-pay-error',
    },

    createRevolutWidgetInstance: function () {
      let payInstance = this.revolutPay()
      let self = this

      if (payInstance !== null) {
        payInstance.destroy()
      }

      payInstance = RevolutCheckout.payments({
        locale: window.checkoutConfig.payment.revolut.locale,
        publicToken: window.checkoutConfig.payment.revolut.publicKey,
      })

      const context = 'checkout'
      const pageUrl = window.checkoutConfig.payment.revolut.checkoutUrl
      const revolutPayRedirectUrl = window.checkoutConfig.payment.revolut.redirectUrl

      const quoteTotals = quote.totals()
      const totalAmount = quoteTotals ? quoteTotals.grand_total : 0
      const currency = quoteTotals ? quoteTotals.quote_currency_code : ''

      const paymentOptions = {
        currency: currency,
        totalAmount: totalAmount * 100,
        validate: () => {
          return self.handleValidate()
        },
        createOrder: () => {
          return self.createOrUpdateRevolutOrder()
        },
        customer: {
          name: self.getBillingName(),
          email: self.getBillingEmail(),
          phone: self.getBillingPhone(),
        },
        __metadata: {
          environment: 'magento',
          context: context,
          origin_url: window.checkoutConfig.payment.revolut.originUrl,
        },
        mobileRedirectUrls: {
          success: revolutPayRedirectUrl,
          failure: pageUrl,
          cancel: pageUrl,
        },
        buttonStyle: {
          cashback: window.checkoutConfig.payment.revolut.revButtonStyle.cashback,
          cashbackCurrency: currency,
          radius: 'none',
          height: '50px',
        },
        __features: {
          skipOrderAmountCheck: true,
        },
      }

      payInstance.revolutPay.mount(
        document.getElementById('revolut-pay-element'),
        paymentOptions,
      )

      payInstance.revolutPay.on('payment', function (event) {
        switch (event.type) {
          case 'success':
            self.handleRevolutPaySuccess()
            break
          case 'error':
            self.handleError({
              message: [event.error.message].filter(Boolean).join(' '),
            })
            break
          case 'cancel':
            self.handleCancel()
            break
        }
      })

      self.revolutPay(payInstance)
      fullScreenLoader.stopLoader()
    },

    getCode: function () {
      return 'revolut_pay'
    },
  })
})
