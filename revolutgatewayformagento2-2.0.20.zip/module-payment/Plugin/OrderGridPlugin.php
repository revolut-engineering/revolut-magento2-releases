<?php
namespace Revolut\Payment\Plugin;

use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Payment;
use Magento\Sales\Model\ResourceModel\Order\Grid\Collection;
use Revolut\Payment\Model\Helper\Logger;
use Revolut\Payment\Model\RevolutOrder;
use Revolut\Payment\Model\Helper\ConstantValue;
use Revolut\Payment\Model\Ui\ConfigProvider;

class OrderGridPlugin
{
    /**
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @var RevolutOrder
     */
    protected $revolutOrder;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * OrderGridPlugin constructor.
     * @param OrderRepositoryInterface $orderRepository
     * @param RevolutOrder $revolutOrder
     * @param Logger $logger
     */
    public function __construct(
        OrderRepositoryInterface $orderRepository,
        RevolutOrder $revolutOrder,
        Logger $logger
    ) {
        $this->orderRepository = $orderRepository;
        $this->revolutOrder = $revolutOrder;
        $this->logger= $logger;
    }

     /**
      * Syncs magento order status with revolut orders
      * @param Collection $subject
      * @param bool $printQuery
      * @param bool $logQuery
      * @return void
      */
    public function beforeLoad(Collection $subject, $printQuery = false, $logQuery = false)
    {
        try {
            $orderIds = $subject->getAllIds();
            $this->syncPendingMagentoOrdersStatus($orderIds);
        } catch (\Throwable $e) {
            $this->logger->debug("OrderGridPlugin->beforeLoad Error : " . $e->getMessage());
        }
    }

    /**
     * Syncs magento order status with revolut orders
     * @param array $orderIds
     * @return void
     */
    private function syncPendingMagentoOrdersStatus($orderIds)
    {

        if (empty($orderIds)) {
            return;
        }

        foreach ($orderIds as $orderId) {
            $order = $this->orderRepository->get($orderId);

            if ($order->getStatus() !== ConstantValue::MAGENTO_PAYMENT_REVIEW_STATUS) {
                continue;
            }

            $payment = $order->getPayment();

            if (! ($payment instanceof Payment)) {
                continue;
            }

            $paymentMethod = $payment->getMethod();

            if (!in_array($paymentMethod, [ConfigProvider::CODE, ConfigProvider::REVOLUT_PAY_CODE, ConfigProvider::REVOLUT_PAYMENT_REQUEST_CODE])) {
                continue;
            }

            $publicId = $payment->getAdditionalInformation('publicId');
        
            if (! $publicId) {
                continue;
            }
    
            $revolutOrder = $this->revolutOrder->retrieveBy('public_id', $publicId);
            if ($revolutOrder->isPaymentCompleted()) {
                $payment->accept();
                $order->save();
            }
        }
    }
}
