<?php

namespace Revolut\Payment\Gateway\Helper;

use Revolut\Payment\Model\Helper\Logger;
use Magento\Directory\Model\CurrencyFactory;

class AmountProvider
{
    /**
     * Verification tolerance for currencies represented in hundredths.
     */
    private const DECIMAL_CURRENCY_VERIFICATION_TOLERANCE = 5;

    /**
     * Zero decimal currencies
     *
     * @var array
     */
    private $zeroDecimal = ['JPY'];

    /**
     * @var Logger
     */
    public $logger;
    
    /**
     * @var CurrencyFactory
     */
    public $currencyFactory;

    /**
     * @param Logger $logger
     * @param CurrencyFactory $currencyFactory
     */
    public function __construct(
        Logger $logger,
        CurrencyFactory $currencyFactory
    ) {
        $this->logger = $logger;
        $this->currencyFactory = $currencyFactory;
    }
    
    /**
     * Convert
     *
     * @param float|mixed $amount
     * @param string $orderCurrency
     * @param string|null $paymentCurrency
     * @param int|float $orderTotal
     * @param int|float $paymentTotal
     * @return mixed
     */
    public function convert($amount, $orderCurrency, $paymentCurrency = '', $orderTotal = 0, $paymentTotal = 0)
    {
        list($amount, $orderCurrency) = $this->checkCurrencyDifference( // @phpstan-ignore-line
            $amount,
            $orderCurrency,
            $paymentCurrency,
            $orderTotal,
            $paymentTotal
        );

        $multiplier = in_array($orderCurrency, $this->zeroDecimal) ? 1 : 100;
        $amount = (int)round($multiplier * $amount);
        if (!empty($paymentCurrency)) {
            $this->logger->debug('converted amount : ' . $amount . ' - currency: ' . $orderCurrency);
            return [$amount, $orderCurrency];
        }
        $this->logger->debug('converted amount : ' . $amount);
        return $amount;
    }

    /**
     * Check CurrencyDifference
     *
     * @param float|mixed $amount
     * @param string $orderCurrency
     * @param string|null $paymentCurrency
     * @param int|float $orderTotal
     * @param int|float $paymentTotal
     *
     * @return mixed
     */
    public function checkCurrencyDifference($amount, $orderCurrency, $paymentCurrency, $orderTotal, $paymentTotal)
    {
        if (empty($paymentCurrency)) {
            return [$amount, $orderCurrency];
        }

        $this->logger->debug('Currency difference check - initialAmount: ' . $amount .
                            ' - paymentCurrency: ' . $paymentCurrency .
                            ' - orderCurrency: ' . $orderCurrency);

        if ($paymentCurrency != $orderCurrency) {
            //if amount is total amount, use total payment amount as converted amount
            $isTotalAmount = $amount == $orderTotal;

            if ($isTotalAmount) {
                $this->logger->debug('use total payment amount as converted: - amount - ' . $amount .
                                    ' paymentTotal - ' . $paymentTotal . ' - paymentCurrency: ' . $paymentCurrency .
                                    ' - orderTotal: ' . $orderTotal . ' - orderCurrency: ' . $orderCurrency);

                return [$paymentTotal, $paymentCurrency];
            }

            $paymentCurrencyObj = $this->currencyFactory->create()->load($paymentCurrency);
            $orderCurrencyObj = $this->currencyFactory->create()->load($orderCurrency);

            $amount = $orderCurrencyObj->convert($amount, $paymentCurrencyObj);  // @phpstan-ignore-line
            $this->logger->debug('Currency difference check - convertedAmount: ' . $amount .
                                 ' - convertedCurrency: ' . $paymentCurrencyObj->getCode());
            return [$amount, $paymentCurrencyObj->getCode()];
        }

        $this->logger->debug('Currency difference check - convertedAmount: ' . $amount);

        return [$amount, $orderCurrency];
    }

     /**
      * Return reverted amount based on currency
      *
      * @param float $amount
      * @param string $currency
      *
      * @return float
      */
    public function revert($amount, $currency)
    {
        $multiplier = in_array($currency, $this->zeroDecimal) ? 1 : 100;

        return round($amount / $multiplier, 2);
    }

    /**
     * Get the acceptable verification difference in Revolut amount units.
     *
     * Zero-decimal currencies cannot tolerate a minor-unit rounding difference,
     * because one Revolut amount unit represents one whole currency unit.
     *
     * @param string $currency
     * @return int
     */
    public function getVerificationTolerance($currency)
    {
        return in_array($currency, $this->zeroDecimal)
            ? 0
            : self::DECIMAL_CURRENCY_VERIFICATION_TOLERANCE;
    }
}
