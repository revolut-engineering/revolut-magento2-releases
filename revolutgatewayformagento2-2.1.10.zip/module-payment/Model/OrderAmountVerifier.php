<?php

namespace Revolut\Payment\Model;

use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment;
use Revolut\Payment\Gateway\Helper\AmountProvider;
use Revolut\Payment\Model\Helper\ConstantValue;
use Revolut\Payment\Model\Helper\Logger;
use Throwable;

class OrderAmountVerifier
{
    /**
     * @var AmountProvider
     */
    private $amountProvider;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param AmountProvider $amountProvider
     * @param Logger $logger
     */
    public function __construct(
        AmountProvider $amountProvider,
        Logger $logger
    ) {
        $this->amountProvider = $amountProvider;
        $this->logger = $logger;
    }

    /**
     * Compare the Magento order total with the amount requested from Revolut.
     *
     * @param Order $magentoOrder
     * @param RevolutOrder $revolutOrder
     * @return bool
     */
    public function verify(Order $magentoOrder, RevolutOrder $revolutOrder)
    {
        try {
            $magentoCurrency = (string)$magentoOrder->getOrderCurrencyCode();
            $revolutOrder->retrieve();
            $revolutOrderData = $revolutOrder->revolutOrder;
            if (!isset(
                $revolutOrderData['order_amount']['value'],
                $revolutOrderData['order_amount']['currency']
            )) {
                throw new \UnexpectedValueException('Current Revolut order amount or currency is missing.');
            }

            $revolutCurrency = (string)$revolutOrderData['order_amount']['currency'];
            $magentoAmount = $this->amountProvider->convert(
                (float)$magentoOrder->getGrandTotal(),
                $magentoCurrency
            );
            $revolutAmount = (int)$revolutOrderData['order_amount']['value'];

            $amountDifference = abs($magentoAmount - $revolutAmount);
            $amountTolerance = $this->amountProvider->getVerificationTolerance($magentoCurrency);

            if ($amountDifference <= $amountTolerance
                && $magentoCurrency === $revolutCurrency
            ) {
                return true;
            }

            $message = __(
                'Warning: Magento order total (%1 %2) does not match Revolut payment total (%3 %4). '
                . 'Something is not correct; please verify the amounts before processing this order.',
                $magentoOrder->getGrandTotal(),
                $magentoCurrency,
                $this->amountProvider->revert($revolutAmount, $revolutCurrency),
                $revolutCurrency
            );

            $magentoOrder->setState(Order::STATE_PAYMENT_REVIEW);
            $magentoOrder->setStatus(ConstantValue::MAGENTO_PAYMENT_REVIEW_STATUS);
            $payment = $magentoOrder->getPayment();
            if ($payment instanceof Payment) {
                $payment->setAdditionalInformation(ConstantValue::AMOUNT_MISMATCH, true);
            }
            $magentoOrder->addCommentToStatusHistory(
                $message,
                ConstantValue::MAGENTO_PAYMENT_REVIEW_STATUS,
                false
            );

            $this->logger->critical((string)$message);

            return false;
        } catch (Throwable $e) {
            $this->logger->critical('Order amount verification failed: ' . $e->getMessage());
            return false;
        }
    }
}
