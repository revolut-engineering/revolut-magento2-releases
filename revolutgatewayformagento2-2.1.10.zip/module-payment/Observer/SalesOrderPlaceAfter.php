<?php

namespace Revolut\Payment\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment;
use Revolut\Payment\Model\Helper\Logger;
use Revolut\Payment\Model\OrderAmountVerifier;
use Revolut\Payment\Model\RevolutOrderFactory;
use Revolut\Payment\Model\Ui\ConfigProvider;
use Throwable;

class SalesOrderPlaceAfter implements ObserverInterface
{
    /**
     * @var RevolutOrderFactory
     */
    private $revolutOrderFactory;

    /**
     * @var OrderAmountVerifier
     */
    private $orderAmountVerifier;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param RevolutOrderFactory $revolutOrderFactory
     * @param OrderAmountVerifier $orderAmountVerifier
     * @param Logger $logger
     */
    public function __construct(
        RevolutOrderFactory $revolutOrderFactory,
        OrderAmountVerifier $orderAmountVerifier,
        Logger $logger
    ) {
        $this->revolutOrderFactory = $revolutOrderFactory;
        $this->orderAmountVerifier = $orderAmountVerifier;
        $this->logger = $logger;
    }

    /**
     * Verify Revolut and Magento totals before Magento persists the placed order.
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        try {
            $order = $observer->getOrder();
            if (!($order instanceof Order)) {
                return;
            }

            $payment = $order->getPayment();
            if (!($payment instanceof Payment) || !$this->isRevolutPayment($payment)) {
                return;
            }

            $publicId = $payment->getAdditionalInformation('publicId');
            if (empty($publicId)) {
                return;
            }

            $revolutOrder = $this->revolutOrderFactory->create();
            $revolutOrder->load($publicId, 'public_id'); // @phpstan-ignore-line

            if (empty($revolutOrder->getId())) {
                $this->logger->critical('Could not verify order amount: Revolut order was not found.');
                return;
            }

            $this->orderAmountVerifier->verify($order, $revolutOrder);
        } catch (Throwable $e) {
            $this->logger->critical('Order amount verification observer failed: ' . $e->getMessage());
        }
    }

    /**
     * Check whether the order uses a Revolut payment method.
     *
     * @param Payment $payment
     * @return bool
     */
    private function isRevolutPayment(Payment $payment)
    {
        return in_array(
            $payment->getMethod(),
            [
                ConfigProvider::CODE,
                ConfigProvider::REVOLUT_PAY_CODE,
                ConfigProvider::REVOLUT_PAYMENT_REQUEST_CODE
            ],
            true
        );
    }
}
