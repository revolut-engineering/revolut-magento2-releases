<?php


namespace Revolut\Payment\Controller\Adminhtml\AuthConnect;

use Exception;
use Magento\Backend\App\Action;
use Magento\Framework\UrlInterface;
use Magento\Framework\Json\Helper\Data;
use Magento\Backend\App\Action\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Driver\File as DriverInterface;
use Revolut\Payment\Infrastructure\ServiceProvider;
use Revolut\Payment\Model\Helper\Api\RevolutApi;
use Revolut\Payment\Model\Helper\Logger;
use Revolut\Payment\Gateway\Config\Config;
use Revolut\Payment\Infrastructure\Config\Environment;

class Setup extends Action
{
    /**
     * @var DirectoryList
     */
    protected $directory;
    
    /**
     * @var DriverInterface
     */
    protected $fileSystem;
    
    /**
     * @var Data
     */
    protected $json;

    /**
     * @var Logger
     */
    protected $logger;
    
    /**
     * @var RevolutApi
     */
    protected $revolutApi;
    
    /**
     * @var Config
     */
    protected $config;
    
    /**
     * @var UrlInterface
     */
    protected $urlHelper;
    
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * Constructor
     *
     * @param Context $context
     * @param Data $json
     * @param Config $config
     * @param Logger $logger
     * @param UrlInterface $urlHelper
     * @param DirectoryList $directory
     * @param StoreManagerInterface $storeManager
     * @param RevolutApi $revolutApi
     * @param DriverInterface $fileSystem
     */
    public function __construct(
        Context $context,
        Data $json,
        Config $config,
        Logger $logger,
        UrlInterface $urlHelper,
        DirectoryList $directory,
        StoreManagerInterface $storeManager,
        RevolutApi $revolutApi,
        DriverInterface $fileSystem
    ) {
        $this->json = $json;
        $this->logger = $logger;
        $this->urlHelper = $urlHelper;
        $this->directory = $directory;
        $this->storeManager = $storeManager;
        $this->config = $config;
        $this->revolutApi = $revolutApi;
        $this->fileSystem = $fileSystem;
        parent::__construct($context);
    }

    public function jsonResponse($response)
    {
        return $this->getResponse()->representJson(
            $this->json->jsonEncode($response)
        );
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $action = $this->getRequest()->getParam('action');

        try {
            switch ($action) {
                case 'exchange':
                    return $this->handleTokenExchange();
                case 'disconnect':
                    return $this->handleDisconnect();
                default:
                    throw new Exception('undefined auth connect action - ' . $action);
            }
        } catch (\Exception $e) {
            $this->logger->debug('AuthConnect Error' . $e->getMessage());
            return $this->jsonResponse(['success' => false, 'errorMsg' =>'Something went wrong. ' . $e->getMessage()]);
        }
    }

    public function getMode()
    {
        $mode = $this->getRequest()->getParam('mode');

        switch ($mode) {
            case 'dev':
                return Environment::DEV;
            case 'live':
                return Environment::PROD;
            default:
                throw new \Exception("unsupported mode - " . $mode);
        }
    }

    public function handleTokenExchange()
    {
        $code = $this->getRequest()->getParam('code');
        $mode = $this->getMode();
        $verifier = $this->getRequest()->getParam('verifier');

        try {
            $this->logger->error($mode);
            $storeId = ServiceProvider::storeProvider()->getCurrentStoreId();
            $token = ServiceProvider::authConnectService($storeId)->exchangeAuthorizationCode($mode, $code, $verifier);
            $this->jsonResponse(['success' => true, 'access_token' => $token->accessToken]);
        } catch (\Exception $e) {
            $this->logger->error('handleTokenExchange Error - ' . $e->getMessage());
            return $this->jsonResponse(['success' => false]);
        }
    }

    public function handleDisconnect()
    {
        $mode = $this->getMode();

        try {
            $storeId = ServiceProvider::storeProvider()->getCurrentStoreId();
            ServiceProvider::authConnectService($storeId)->disconnect($mode);
            return $this->jsonResponse(['success' => true]);
        } catch (\Exception $e) {
            $this->logger->error('handleDisconnect Error - ' . $e->getMessage());
            return $this->jsonResponse(['success' => true, 'error' => $e->getMessage()]);
        }
    }
}
