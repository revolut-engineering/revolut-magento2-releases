<?php

namespace Revolut\Payment\Model\Helper\Api;

use Revolut\Payment\Model\Helper\ConstantValue;
use Revolut\Payment\Model\Ui\ConfigProvider;
use Revolut\Payment\Infrastructure\ServiceProvider;

class RevolutOrderApi extends RevolutApi
{
     /**
      * Create Order via API
      *
      * @param array $params
      * @param int $storeId
      * @param string $paymentMethod
      * @return array
      */
    public function create($params, $storeId, $paymentMethod)
    {

        $captureMode = $paymentMethod === ConfigProvider::PAY_BY_BANK_CODE ?
            ConstantValue::REVOLUT_AUTHORIZE_CAPTURE_NEW_API :
            ConstantValue::REVOLUT_AUTHORIZE_ONLY_NEW_API;

        $params = [
            "amount" => $params['amount'],
            "currency" => $params['currency'],
            "capture_mode" => $captureMode
        ];

        $locationId = $this->config->getLocationSetupId($storeId);

        if ($locationId) {
            $params['location_id'] = $locationId;
        }

        if (!$this->config->isManualCapture($storeId) && $paymentMethod !== ConfigProvider::PAY_BY_BANK_CODE) {
            $params["cancel_authorised_after"] = ConstantValue::AUTO_CANCEL_TIMEOUT;
        }

        $order = ServiceProvider::privateMerchantApi($storeId)->post($this->getApiUrl(), $params);

        if (isset($order['token'])) {
            $order['public_id'] = $order['token'];
        }

        return $order;
    }

    /**
     * Update Order amount via API
     *
     * @param string $orderId
     * @param array $params
     * @param int $storeId
     * @return array
     */
    public function update($orderId, $params, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->patch($this->getApiUrl($orderId), ["amount" => $params['amount'], "currency" => $params['currency']]);
    }

    /**
     * Get Order via API
     *
     * @param string $orderId
     * @param int $storeId
     * @return array
     */
    public function retrieve($orderId, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->get($this->getApiUrl($orderId));
    }

    /**
     * Cancel Order via API
     *
     * @param string $orderId
     * @param int $storeId
     * @return array
     */
    public function cancel($orderId, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->post($this->getApiUrl($orderId, 'cancel'));
    }

    /**
     * Get Order via API
     *
     * @param string $orderId
     * @param int $amount
     * @param int $storeId
     * @return array
     */
    public function capture($orderId, $amount, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->post($this->getApiUrl($orderId, 'capture'), ["amount" => $amount]);
    }

    /**
     * Refund Order via API
     *
     * @param string $orderId
     * @param int $amount
     * @param string $currency
     * @param int $storeId
     * @return array
     */
    public function refund($orderId, $amount, $currency, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->post($this->getApiUrl($orderId, 'refund'), ["amount" => $amount, "currency" => $currency]);
    }

    /**
     * Update Order Merchant ref via API
     *
     * @param string $orderId
     * @param mixed $merchantOrderId
     * @param int $storeId
     * @return array
     */
    public function updateMerchantOrderId($orderId, $merchantOrderId, $storeId)
    {
        return ServiceProvider::legacyMerchantApi($storeId)->patch($this->getApiUrl($orderId), ["merchant_order_ext_ref" => $merchantOrderId]);
    }
    
    /**
     * Update Order Merchant ref via API
     *
     * @param string $orderId
     * @param array $lineItems
     * @param int $storeId
     * @return array
     */
    public function updateLineItems($orderId, $lineItems, $storeId)
    {
        return ServiceProvider::privateMerchantApi($storeId)->patch($this->getApiUrl($orderId), $lineItems);
    }

    /**
     * Get Orders API URL
     *
     * @param string $orderId
     * @param string $action
     * @return string
     */
    public function getApiUrl($orderId = '', $action = '')
    {
        $apiUrl =  '/' . ConstantValue::ENDPOINT_ORDER;

        if ($orderId) {
            $apiUrl .= '/' . $orderId;
        }
        
        if ($action) {
            $apiUrl .= '/' . $action;
        }

        return $apiUrl;
    }
}
