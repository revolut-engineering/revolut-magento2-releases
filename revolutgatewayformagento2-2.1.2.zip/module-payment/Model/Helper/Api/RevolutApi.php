<?php

namespace Revolut\Payment\Model\Helper\Api;

use Revolut\Payment\Gateway\Helper\AmountProvider;
use Magento\Framework\Json\Helper\Data;
use Magento\Framework\App\Helper\Context;
use Revolut\Payment\Model\Helper\ConstantValue;
use Revolut\Payment\Gateway\Config\Config;
use Revolut\Payment\Gateway\Config\PayByBank\Config as PayByBankConfig;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Revolut\Payment\Infrastructure\ServiceProvider;
use Revolut\Payment\Model\Helper\Logger;

class RevolutApi extends AbstractHelper
{
    /**
     * @var Config
     */
    protected $config;

    /**
     * @var PayByBankConfig
     */
    protected $payByBankConfig;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * RevolutApi constructor.
     *
     * @param Config $config
     * @param PayByBankConfig $payByBankConfig
     * @param Data $jsonHelper
     * @param Context $context
     */
    public function __construct(
        Config $config,
        PayByBankConfig $payByBankConfig,
        Data $jsonHelper,
        Context $context
    ) {
        parent::__construct($context);
        $this->config = $config;
        $this->jsonHelper = $jsonHelper;
        $this->payByBankConfig = $payByBankConfig;
    }

    /**
     * @param  mixed $response
     * @return array
     */
    public function json($response)
    {
        return (array)$this->jsonHelper->jsonDecode($response); // @phpstan-ignore-line
    }
    
    /**
     * @param  int $storeId
     * @return string|mixed
     */
    public function getMerchantPublicKey($storeId)
    {
        $response = ServiceProvider::privateMerchantApi($storeId)->get('/public-key/latest');
        $publicKey = isset($response['public_key']) ?  (string)$response['public_key'] : '';
        return $publicKey;
    }
    
    /**
     * @param int $storeId
     * @param string $currency
     * @param int|mixed $amount
     * @return array
     */
    public function getAvailableCardBrands($storeId, $currency, $amount)
    {
        $availableCardBrands = $this->config->getAvailableCardBrands($storeId);

        if ($availableCardBrands) {
            $availableCardBrands = $this->json($availableCardBrands);
        }
        
        if ($availableCardBrands) {
            return $availableCardBrands;
        }

        $response = ServiceProvider::publicMerchantApi($storeId)->get('/available-payment-methods?amount=' . $amount .'&currency=' . $currency);
        $availableCardBrands = isset($response['available_card_brands']) ? $response['available_card_brands'] : [];
        
        if (!$availableCardBrands) {
            return [];
        }

        $this->config->saveAvailableCardBrands($this->jsonHelper->jsonEncode($availableCardBrands), $storeId);
        return $availableCardBrands;
    }
    /**
     * Returns bank brands
     *
     * @param string $currency
     * @param int $storeId
     * @return array
     */
    public function fetchBankBrands($currency, $storeId)
    {
        $brands = $this->payByBankConfig->getBankBrands($currency, $storeId);
        
        if (!empty($brands)) {
            return $brands;
        }

        $bankBrands = ServiceProvider::publicMerchantApi($storeId)->get('/open-banking/external-institutions?currency=' . $currency);
        
        if (!empty($bankBrands) && is_array($bankBrands)) {
            $this->payByBankConfig->saveBankBrands($bankBrands, $currency, $storeId);
            return $this->jsonHelper->jsonEncode($bankBrands);
        }

        return $this->jsonHelper->jsonEncode([]);
    }

    /**
     * @param string $domain
     * @param int $storeId
     * @return array
     */
    public function registerApplePayDomain($domain, $storeId)
    {
        return ServiceProvider::privateMerchantApi($storeId)->post('/api/apple-pay/domains/register', ["domain" => $domain]);
    }
    
    /**
     * @param int $storeId
     * @return array
     */
    public function getLocations($storeId)
    {
        return ServiceProvider::privateMerchantApi($storeId)->get('/locations');
    }
    
    /**
     * @param int $storeId
     * @param array $location
     * @return array
     */
    public function createLocation($storeId, $location)
    {
        return ServiceProvider::privateMerchantApi($storeId)->post('/locations', $location);
    }
    
    /**
     * @param int $storeId
     * @param array $webhook
     * @return array
     */
    public function registerAddressValidationWebhook($storeId, $webhook)
    {
        return ServiceProvider::privateMerchantApi($storeId)->post('/synchronous-webhooks', $webhook);
    }

    /**
     * Returns list of merchant public features
     *
     * @param int $storeId
     * @return array
     */
    public function getMerchantFeatures($storeId)
    {
        $response = ServiceProvider::publicMerchantApi($storeId)->get('/merchant');

        if (isset($response['features']) && is_array($response['features'])) {
            return $response['features'];
        }

        return [];
    }
}
