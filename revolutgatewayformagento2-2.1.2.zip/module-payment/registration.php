<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Revolut_Payment',
    __DIR__
);

require_once __DIR__ . '/lib/vendor/autoload.php';
