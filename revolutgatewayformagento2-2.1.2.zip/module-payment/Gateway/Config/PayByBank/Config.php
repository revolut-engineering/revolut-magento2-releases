<?php

namespace Revolut\Payment\Gateway\Config\PayByBank;

use Magento\Framework\Json\Helper\Data;
use Magento\Framework\Encryption\Encryptor;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Config\Model\ResourceModel\Config as ConfigInterface;

class Config extends \Magento\Payment\Gateway\Config\Config
{
    public const TITLE = 'Pay by bank';
    public const IS_ACTIVE = 'active';
    public const CONFIG_CODE = 'payment/revolut_pay_by_bank/';

    /**
     * @var Encryptor
     */
    protected $encryptor;

    /**
     * @var ConfigInterface
     */
    protected $configInterface;

    /**
     * @var TypeListInterface
     */
    protected $cacheTypeList;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param Encryptor $encryptor
     * @param ConfigInterface $configInterface
     * @param TypeListInterface $cacheTypeList
     * @param Data $jsonHelper
     * @param string|null $methodCode
     * @param string $pathPattern
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Encryptor $encryptor,
        ConfigInterface $configInterface,
        TypeListInterface $cacheTypeList,
        Data $jsonHelper,
        $methodCode = null,
        $pathPattern = self::DEFAULT_PATH_PATTERN
    ) {
        parent::__construct($scopeConfig, $methodCode, $pathPattern);
        
        $this->encryptor = $encryptor;
        $this->configInterface = $configInterface;
        $this->cacheTypeList = $cacheTypeList;
        $this->scopeConfig = $scopeConfig;
        $this->jsonHelper = $jsonHelper;
    }

    /**
     * @param int $storeId
     * @param string $currency
     * @return array
     */
    public function getBankBrands($storeId, $currency)
    {
        $mode = $this->getValue('api_mode', $storeId);
        $option_key = "revolut_{$mode}_{$currency}_openbanking_bank_brands";
        return (bool) $this->scopeConfig->getValue(
            self::CONFIG_CODE . $option_key,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     *
     * @param array $brands
     * @param string $currency
     * @param int $storeId
     * @return void
     */
    public function saveBankBrands($brands, $currency, $storeId)
    {
        $mode = $this->getValue('api_mode', $storeId);
        $option_key = "revolut_{$mode}_{$currency}_openbanking_bank_brands";
        $encoded_brands = $this->jsonHelper->jsonEncode($brands);
        $this->configInterface->saveConfig(
            self::CONFIG_CODE . $option_key,
            (string) $encoded_brands,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
}
