<?php

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Infrastructure\Api\Auth\AccessTokenAuthStrategy;
use Revolut\Plugin\Infrastructure\Api\Auth\AuthStrategyFactory;
use Revolut\Plugin\Infrastructure\Api\MerchantApi;
use Revolut\Plugin\Infrastructure\Api\MerchantApiClient;
use Revolut\Plugin\Infrastructure\Lock\TokenRefreshJobLockService;
use Revolut\Plugin\Infrastructure\Lock\TokenRefreshLockService;
use Revolut\Plugin\Infrastructure\Repositories\OptionTokenRepository;
use Revolut\Plugin\Services\AuthConnect\AuthConnect;
use Revolut\Plugin\Services\Config\Api\ConfigInterface;
use Revolut\Plugin\Services\Log\RLog;
use Revolut\Payment\Infrastructure\AuthConnectJob;
use Revolut\Payment\Infrastructure\Config\ApiConfigProvider;
use Revolut\Payment\Infrastructure\HttpClient;
use Revolut\Payment\Infrastructure\Logger;
use Revolut\Payment\Infrastructure\OptionRepository;
use Revolut\Payment\Infrastructure\StoreProvider;
use Magento\Framework\App\ObjectManager;

class ServiceProvider
{
    public static function storeProvider(): StoreProvider
    {
        return new StoreProvider();
    }

    public static function apiConfigProvider($storeId): ApiConfigProvider
    {
        return new ApiConfigProvider($storeId, self::optionTokenRepository($storeId));
    }

    public static function optionRepository($storeId): OptionRepository
    {
        return new OptionRepository($storeId);
    }

    public static function optionTokenRepository($storeId): OptionTokenRepository
    {
        return new OptionTokenRepository(self::optionRepository($storeId));
    }

    public static function tokenRefreshLockService($storeId): TokenRefreshLockService
    {
        return new TokenRefreshLockService(self::optionRepository($storeId));
    }

    public static function tokenRefreshJobLockService($storeId): TokenRefreshJobLockService
    {
        return new TokenRefreshJobLockService(self::optionRepository($storeId));
    }

    public static function httpClient(): HttpClient
    {
        return new HttpClient();
    }

    public static function authStrategyFactory($storeId): AuthStrategyFactory
    {
        return new AuthStrategyFactory(
            self::apiConfigProvider($storeId),
            self::tokenRefreshLockService($storeId),
            self::optionTokenRepository($storeId),
            self::authConnectService($storeId)
        );
    }

    public static function authConnectService($storeId): AuthConnect
    {
        return new AuthConnect(
            self::optionTokenRepository($storeId),
            self::httpClient(),
            self::apiConfigProvider($storeId),
            self::tokenRefreshLockService($storeId)
        );
    }

    public static function authConnectJob($storeId): AuthConnectJob
    {
        return new AuthConnectJob(
            self::tokenRefreshJobLockService($storeId),
            self::authConnectService($storeId)
        );
    }

    public static function initMerchantApi($storeId): void
    {
        MerchantApi::init(
            self::authStrategyFactory($storeId),
            self::httpClient()
        );
    }

    public static function privateMerchantApi($storeId): MerchantApiClient
    {
        self::initMerchantApi($storeId);
        return MerchantApi::private();
    }

    public static function legacyMerchantApi($storeId): MerchantApiClient
    {
        self::initMerchantApi($storeId);
        return MerchantApi::privateLegacy();
    }

    public static function publicMerchantApi($storeId): MerchantApiClient
    {
        self::initMerchantApi($storeId);
        return MerchantApi::public();
    }

    public static function logger(): Logger
    {
        $logger = new Logger();
        $logger::setLogger(ObjectManager::getInstance()->get('Revolut\Payment\Model\Helper\Logger'));
        
        RLog::setLogger(
            $logger,
            ['source' => 'revolut-gateway-for-prestashop']
        );

        return $logger;
    }
}
