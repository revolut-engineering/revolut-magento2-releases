<?php

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Services\Http\HttpClientInterface;
use Revolut\Payment\Model\Helper\ConstantValue;
use Magento\Framework\App\ObjectManager;
use Revolut\Payment\Infrastructure\ServiceProvider;

class HttpClient implements HttpClientInterface
{
    private $productMetadata;
    private $moduleList;

    public function __construct()
    {
        $this->productMetadata = ObjectManager::getInstance()->get('Magento\Framework\App\ProductMetadataInterface');
        $this->moduleList = ObjectManager::getInstance()->get('Magento\Framework\Module\ModuleListInterface');
    }

    public function getClient()
    {
        if (class_exists(\Laminas\Http\Client::class)) {
            return new \Laminas\Http\Client();
        } elseif (class_exists(\Zend\Http\Client::class)) {
            return new \Zend\Http\Client();
        } else {
            throw new \RuntimeException('Neither Laminas nor Zend HTTP client is available.');
        }
    }

    public function request(string $method, string $url, array $options = []): array
    {
        $method = strtoupper($method);
        $headers = $options['headers'] ?? [];
        $body = $options['body'] ?? null;
        $query = $options['query'] ?? [];

        $client = $this->getClient();
        $client->resetParameters();
        $client->setUri($url);
        $client->setMethod($method);
        $client->setHeaders($this->withUserAgent($headers));
        $client->setOptions([
            'timeout' => 10,
        ]);

        if (!empty($query)) {
            $client->setParameterGet($query);
        }

        if (!empty($body)) {
            $client->setRawBody($body);
            $client->setEncType($headers['Content-Type']);
        }

        try {
            $response = $client->send();
            return [
                'status' => $response->getStatusCode(),
                'body' => $response->getBody()
            ];
        } catch (\Exception $e) {
            return [
                'status' => 0,
                'body' => $e->getMessage(),
                'error' => true,
            ];
        }
    }

    public function withUserAgent(array $headers)
    {
        $setup_version =  $this->moduleList->getOne(ConstantValue::MODULE_NAME)['setup_version'];

        $headers['User-Agent'] = 'Revolut Payment Gateway/' . $setup_version
                                 . ' Magento/' . $this->productMetadata->getVersion()
                                    . ' PHP/' . PHP_VERSION;

        return $headers;
    }

    public function getStatusCode(array $response): int
    {
        return $response['status'] ?? 0;
    }

    public function getBody(array $response): array
    {
        return json_decode($response['body'], true) ?? [];
    }

    public function isError(array $response): bool
    {
        return $response['error'] ?? false;
    }

    public function getErrorMessage(array $response): ?string
    {
        return $response['body'] ?? null;
    }
}
