<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    Revolut
 * @copyright Since 2020 Revolut
 * @license   https://opensource.org/licenses/AFL-3.0  Academic Free License (AFL 3.0)
 */

namespace Revolut\Payment\Infrastructure;

use Revolut\Plugin\Services\AuthConnect\Exceptions\TokenRefreshInProgressException;
use Revolut\Plugin\Services\AuthConnect\TokenRefreshServiceInterface;
use Revolut\Plugin\Services\Lock\LockInterface;
use Revolut\Plugin\Services\Log\RLog;

class AuthConnectJob
{
    private $tokenRefreshJobLock;

    private $tokenRefreshService;

    public function __construct(
        LockInterface $tokenRefreshJobLock,
        TokenRefreshServiceInterface $tokenRefreshService
    ) {
        $this->tokenRefreshJobLock = $tokenRefreshJobLock;
        $this->tokenRefreshService = $tokenRefreshService;
    }

    public function run()
    {
        try {
            $this->refreshTokenJob();
        } catch (\Exception $e) {
            if ($e instanceof TokenRefreshInProgressException) {
                return;
            }

            RLog::error('refresh_token job error. ' . $e->getMessage());
        }
    }

    public function refreshTokenJob()
    {
        if (!$this->tokenRefreshJobLock->acquire()) {
            throw new TokenRefreshInProgressException('token refresh in progress...');
        }

        try {
            RLog::info('refresh_token job start.');
            // On Multi store suported platforms as Magento
            // Refresh job and on demand refresh process should run **Synonymously**
            // Due to the fact that only 2 refresh process could run asynchronously
            $this->tokenRefreshService->tryRefreshTokenWithLock();
            RLog::info('refresh_token job completed.');
        } catch (\Exception $e) {
            $dt = \DateTime::createFromFormat('U.u', (string) microtime(true));
            RLog::error('refreshToken error - ' . $e->getMessage() . ' - ' . $dt->format('H:i:s.u'));
        }
    }
}
