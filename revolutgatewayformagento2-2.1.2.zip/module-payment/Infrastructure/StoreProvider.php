<?php

namespace Revolut\Payment\Infrastructure;

use Magento\Framework\App\ObjectManager;

class StoreProvider
{

    protected $storeManager;
    protected $request;

    public function __construct()
    {
        $this->storeManager = ObjectManager::getInstance()->get('Magento\Store\Model\StoreManagerInterface');
        $this->request = ObjectManager::getInstance()->get('Magento\Framework\App\RequestInterface');
    }

    public function getCurrentStoreId()
    {
        // Admin context — check for store param
        $storeId = (int) $this->request->getParam('store');

        if ($storeId) {
            return $storeId;
        }

        $websiteCode = $this->request->getParam('website');
        if ($websiteCode) {
            $website = $this->storeManager->getWebsite($websiteCode);
            return (int) $website->getDefaultStore()->getId();
        }

        $scope = $this->request->getParam('scope');
        if ($scope && $scope !== ScopeInterface::SCOPE_DEFAULT) {
            return (int) $this->storeManager->getStore($scope)->getId();
        }

        return (int) $this->storeManager->getStore()->getId();
    }
}
