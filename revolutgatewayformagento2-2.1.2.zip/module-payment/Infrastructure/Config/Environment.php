<?php

namespace Revolut\Payment\Infrastructure\Config;

class Environment
{
    public const DEV = 2;
    public const SANDBOX = 1;
    public const PROD = 0;
}
