<?php

namespace Revolut\Payment\Infrastructure;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\LocalizedException;
use Revolut\Plugin\Services\Repositories\OptionRepositoryInterface;

class OptionRepository implements OptionRepositoryInterface
{
    protected $connection;
    protected $tableName;
    protected $storeId;

    public function __construct($storeId)
    {
        $resource = ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
        $this->connection = $resource->getConnection();
        $this->tableName = $resource->getTableName('revolut_options');
        $this->storeId = $storeId;
    }

    private function maybeEncode($value)
    {
        if (is_array($value)) {
            return json_encode($value);
        }

        return $value;
    }

    private function maybeDecode($value)
    {
        if (is_string($value) && $this->isJson($value)) {
            $decoded = json_decode($value, true);

            return (json_last_error() === JSON_ERROR_NONE) ? $decoded : $value;
        }

        return $value;
    }

    private function isJson($string)
    {
        if (!is_string($string)) {
            return false;
        }
        json_decode($string);

        return json_last_error() === JSON_ERROR_NONE;
    }

    public function add($name, $value)
    {
        try {
            $this->connection->insert($this->tableName, [
                'store_id' => $this->storeId,
                'option_name' => $name,
                'option_value' => $this->maybeEncode($value)
            ]);
            return true;
        } catch (\Zend_Db_Statement_Exception $e) {
            // Duplicate entry due to UNIQUE constraint
            return false;
        } catch (\Exception $e) {
            if (strpos($e->getMessage(), 'SQLSTATE[23000]') !== false) {
                // Duplicate entry due to UNIQUE constraint
                return false;
            }
            throw new LocalizedException(__('Add failed: %1', $e->getMessage()));
        }
    }

    public function delete($name)
    {
        return (bool) $this->connection->delete($this->tableName, ['option_name = ?' => $name, 'store_id = ?' => $this->storeId]);
    }

    public function update($name, $value)
    {
        return (bool) $this->connection->update(
            $this->tableName,
            ['option_value' => $this->maybeEncode($value)],
            ['option_name = ?' => $name, 'store_id = ?' => $this->storeId]
        );
    }

    public function addOrUpdate($name, $value)
    {
        try {
            $this->connection->insertOnDuplicate(
                $this->tableName,
                ['store_id' => $this->storeId, 'option_name' =>  $name, 'option_value' => $this->maybeEncode($value)],
                ['option_value']
            );
            return true;
        } catch (\Exception $e) {
            throw new LocalizedException(__('addOrUpdate failed: %1', $e->getMessage()));
        }
    }

    public function get($name)
    {
        $select = $this->connection->select()
            ->from($this->tableName, ['option_value'])
            ->where('option_name = :name')
            ->where('store_id = ?', $this->storeId);

        $result = $this->connection->fetchOne($select, ['name' => $name]);
        return $result !== false ?  $this->maybeDecode($result) : null;
    }
}
