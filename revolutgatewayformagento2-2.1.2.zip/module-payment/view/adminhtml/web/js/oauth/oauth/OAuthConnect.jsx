import React from 'react'

import { useEffect, useState, useRef } from 'react'

import {
  Overlay,
  Flex,
  Box,
  VStack,
  Button,
  Text,
  Grid,
  Separator,
  Status,
  TextButton,
  Popup,
  Header,
} from '@revolut/ui-kit'

import { uuid, openCenteredPopup } from './utils'
import { borderRadius } from 'styled-system'

const OAuthFlowState = {
  OAUTH_COMPLETED: 'complete',
  OAUTH_TIMEOUT: 'timeout',
}

export const OAuthConnect = ({ mode }) => {
  const storeHasValidTokens = window.ConnectVars.store_has_valid_tokens

  const [open, toggleOpen] = useState(false)
  const [isRemoveConnectionConfirmationOpen, openRemoveConnectionConfirmation] =
    useState(false)
  const [isConnectButtonDisabled, setConnectButtonDisabled] =
    useState(storeHasValidTokens)

  const [hasValidTokens, setHasValidTokens] = useState(storeHasValidTokens)

  const [connectionErrorMsg, setConnectionErrorMsg] = useState('')
  const [connectionSuccessMsg, setConnectionSuccessMsg] = useState('')
  const popupWindow = useRef(null)
  const clientState = useRef(null)

  const getConnectServerUrl = mode => {
    return ConnectVars[`connect_server_url_${mode}`]
  }

  const exchangeAuthorizationCode = (code, verifier) => {
    setConnectionSuccessMsg('Exchanging code for tokens...')
    jQuery.ajax({
      type: 'POST',
      dataType: 'json',
      url: window.ConnectVars.ajax_url,
      data: {
        ajax: true,
        action: 'exchange',
        code: code,
        mode: mode,
        verifier: verifier,
      },
      success: function (response) {
        if (response.success) {
          setConnectButtonDisabled(true)
          setHasValidTokens(true)
          setConnectionSuccessMsg('Account connection completed successfully!')
        } else {
          setConnectButtonDisabled(false)
          setConnectionSuccessMsg('')
          setConnectionErrorMsg(
            'Error: ' + (response.data || 'Could not complete connection.'),
          )
        }
      },
      error: function (xhr, status, error) {
        setConnectButtonDisabled(false)
        setConnectionSuccessMsg('')
        setConnectionErrorMsg('Error: ' + (error || 'Unexpected AJAX failure.'))
      },
    })
  }

  const removeConnection = () => {
    setConnectionSuccessMsg()
    setHasValidTokens(false)
    openRemoveConnectionConfirmation(false)
    popupWindow.current = null
    clientState.current = null

    jQuery.ajax({
      type: 'POST',
      dataType: 'json',
      url: window.ConnectVars.ajax_url,
      data: {
        action: 'disconnect',
        mode: mode,
      },
      success: function (response) {
        if (response.success) {
          setConnectButtonDisabled(false)
        }
      },
      error: function (xhr, status, error) {
        setConnectionSuccessMsg('')
        setConnectionErrorMsg('Error: ' + (error || 'Unexpected AJAX failure.'))
      },
    })
  }

  const closePollingPopup = () => {
    setTimeout(() => {
      if (popupWindow.current) {
        popupWindow.current.close()
      }
    }, 500)
  }

  const openPollingPopup = clientState => {
    if (popupWindow.current) {
      popupWindow.current.focus()
      return
    }

    const connectServerOrigin = new URL(getConnectServerUrl(mode)).origin
    popupWindow.current = openCenteredPopup(
      connectServerOrigin + '/connect/' + clientState,
      'connect_popup',
      400,
      500,
    )

    const listenPopupWindoCloseEvent = setInterval(function () {
      if (popupWindow.current.closed) {
        clearInterval(listenPopupWindoCloseEvent)
        popupWindow.current = null
      }
    }, 500)
  }

  const redirectToAuthFlow = clientState => {
    window.open(
      getConnectServerUrl(mode) +
        '/oauth/start?client_state=' +
        clientState +
        '&origin=' +
        window.origin,
      '_blank',
    )
  }

  const onFocusPopup = () => {
    if (popupWindow.current) {
      popupWindow.current.focus()
    } else {
      openPollingPopup(clientState.current)
    }
  }

  const handleConnectClick = () => {
    // exchangeAuthorizationCode('c', 'v')
    // return
    toggleOpen(true)
    setConnectButtonDisabled(true)
    const _clientState = encodeURIComponent(uuid())
    redirectToAuthFlow(_clientState)
    clientState.current = _clientState
  }

  const onWidowBeforeunload = () => {
    if (popupWindow.current) {
      popupWindow.current.close()
    }
  }

  useEffect(() => {
    window.addEventListener('beforeunload', event => onWidowBeforeunload())

    return () => {
      window.removeEventListener('beforeunload', event => onWidowBeforeunload())
    }
  }, [])

  const onMessageEvent = event => {
    const connectServerOrigin = new URL(getConnectServerUrl(mode)).origin

    if (event.origin === connectServerOrigin) {
      const oauth_status = event.data.eventType
      const payload = event.data.payload
      if (oauth_status == OAuthFlowState.OAUTH_COMPLETED) {
        setConnectionSuccessMsg('Connected!')
        setConnectButtonDisabled(true)
        exchangeAuthorizationCode(payload.code, payload.code_verifier)
        closePollingPopup()
        toggleOpen(false)
      } else if (oauth_status == OAuthFlowState.OAUTH_TIMEOUT) {
        setConnectionSuccessMsg('')
        setConnectionErrorMsg('Connection timed out.')
        setConnectButtonDisabled(false)
        closePollingPopup()
        toggleOpen(false)
      } else {
        console.error('unexpected oauth flow status - ' + event.data.eventType)
      }
    }
  }

  useEffect(() => {
    window.addEventListener('message', event => onMessageEvent(event))
    return () => {
      window.removeEventListener('message', event => onMessageEvent(event))
    }
  }, [])

  const closeOverlay = () => {
    setConnectButtonDisabled(false)
    closePollingPopup()
    toggleOpen(false)
  }

  return (
    <>
      <Box width={250} height={40}>
        <Text fontSize={14}>OR</Text>
      </Box>
      <Box width={250} height={30}>
        <Button
          disabled={isConnectButtonDisabled}
          variant="primary"
          size="large"
          onClick={handleConnectClick}
        >
          {mode == 'dev' && 'DEV - '}
          {!hasValidTokens && 'Connect your Merchant account'}
          {hasValidTokens && 'Connected'}
        </Button>
      </Box>
      {hasValidTokens && (
        <Box marginTop={5}>
          <TextButton
            variant="negative"
            fontSize={12}
            onClick={() => openRemoveConnectionConfirmation(true)}
          >
            Remove Connection
          </TextButton>
        </Box>
      )}
      <>
        <Popup
          id="rev-plugin-popup"
          open={isRemoveConnectionConfirmationOpen}
          variant="bottom-sheet"
        >
          <Header variant="bottom-sheet">
            <Header.Title>Remove OAuth Connection?</Header.Title>
          </Header>
          <Popup.Actions>
            <Button elevated onClick={removeConnection}>
              Yes
            </Button>
            <Button
              variant="secondary"
              onClick={() => openRemoveConnectionConfirmation(false)}
            >
              No
            </Button>
          </Popup.Actions>
        </Popup>
      </>
      <Box marginTop={10}>
        {connectionErrorMsg && (
          <Status useIcon="ExclamationMarkOutline" color="red">
            {connectionErrorMsg}
          </Status>
        )}
        {connectionSuccessMsg && (
          <Status useIcon="16/StatusActive" iconColor="green">
            {connectionSuccessMsg}
          </Status>
        )}
      </Box>

      <Overlay
        id="rev-plugin-overlay"
        bg="black-80"
        open={open}
        closeOnEsc={true}
        useTransition={false}
      >
        <Overlay.CloseButton aria-label="Close" onClick={closeOverlay} />
        <Flex
          alignItems="center"
          justifyContent="center"
          height="100%"
          maxWidth="400px"
          m="auto"
        >
          <Grid>
            <VStack space="s-48">
              <Text variant="emphasis1" color="background" textAlign="center">
                OAuth Connection process in progress. Don’t see the popup screen to
                complete the flow? Click the button below to check connection result
              </Text>
              <Box px="s-24" py="s-24">
                <Button variant="primary" bg="white-20" onClick={onFocusPopup}>
                  Complete Connection
                </Button>
              </Box>
            </VStack>
          </Grid>
        </Flex>
      </Overlay>
    </>
  )
}
