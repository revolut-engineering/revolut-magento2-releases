export const uuid = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = (Math.random() * 16) | 0,
      v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

export const openCenteredPopup = (url, title, width, height) => {
  const screenLeft = window.screenLeft !== undefined ? window.screenLeft : screen.left
  const screenTop = window.screenTop !== undefined ? window.screenTop : screen.top

  const screenWidth =
    window.innerWidth || document.documentElement.clientWidth || screen.width
  const screenHeight =
    window.innerHeight || document.documentElement.clientHeight || screen.height

  const left = screenLeft + (screenWidth - width) / 2
  const top = screenTop + (screenHeight - height) / 2

  const popup = window.open(
    url,
    title,
    `width=${width},height=${height},top=${top},left=${left},resizable,scrollbars`,
  )

  if (!popup) {
    alert('Popup was blocked')
    return
  }

  popup.focus()
  return popup
}
