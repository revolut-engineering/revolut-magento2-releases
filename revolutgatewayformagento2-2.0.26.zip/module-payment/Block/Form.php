<?php

namespace Revolut\Payment\Block;

use Magento\Payment\Block\Form\Cc;

/**
 * @codeCoverageIgnore
 */
class Form extends Cc
{
    
}
