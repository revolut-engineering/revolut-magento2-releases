<?php

namespace Revolut\Payment\Gateway\Response;

use Magento\Payment\Gateway\Response\HandlerInterface;
use Revolut\Payment\Model\Helper\ConstantValue;
use Magento\Sales\Model\Order\Payment;
use Revolut\Payment\Gateway\SubjectReader;

class AuthorizationResultHandler implements HandlerInterface
{
    /**
     * @var SubjectReader
     */
    private $subjectReader;

    /**
     * @param SubjectReader $subjectReader
     */
    public function __construct(
        SubjectReader $subjectReader
    ) {
        $this->subjectReader = $subjectReader;
    }

    /**
     * @param array $handlingSubject
     * @param array $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        $revolutOrder = $this->subjectReader->readRevolutOrder($response);
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);
        $payment = $paymentDO->getPayment();
        $payment->setIsTransactionPending($revolutOrder->isPayByBankPayment());
        $payment->setIsTransactionClosed(false);
        $payment->setShouldCloseParentTransaction(false);

        $webhookAction = $revolutOrder->isPayByBankPayment() ? ConstantValue::WEBHOOK_ACTION_ACCEPT_PAYMENT : ConstantValue::WEBHOOK_ACTION_CAPTURE_PAYMENT;

        $payment->setAdditionalInformation(ConstantValue::WEBHOOK_ACTION, $webhookAction);
    }
}
